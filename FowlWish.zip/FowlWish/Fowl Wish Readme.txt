Mod Name: A Fowl Wish
Premise: A mage’s apprentice accidentally give a Candle of Limited Wish 
to a noble to use at his pet chicken’s birthday party! It’s up to the PC 
to get the candle back before the candle is used. Who knows what the bird 
would Wish for, and what havoc the magic would cause?


WALKTHROUGH
	-Go to the Copper Coronet. Talk to the Panicking Mage Apprentice, near the stairs near where Hexxat is
	-Agree to his quest
	-Go into the Gorinel Estate in the Government District (you get 6,000 xp for getting in, split between party members)
		-You can walk in if you have a Bard in the group
		-You can bribe the guard  for 2000 gold
		-You can bring the Birthday Chicken some Millet Berries as a gift. Get them from Mira in Waukeen's Promenade
		-If you are (in)famous enough, the guard will let you in due to your reputation
	-Talk to the servant. Agree to her quest
		-Go to Pai'Na's nest. Kill the Tasty Looking Spider, and bring it's body to the servant
	-Decide what to do with the Candle
		-return it to the apprentice and reap the rewards
		-keep it for yourself
The end!

REWARDS
	- one-use Candle of Limited Wish and whatever the Panicking Mage Apprentice is carrying.
	- OR +1 reputation, 4000 gold, 15k xp per party member, and Sir Beatrice the Brave (chicken item that can cast Resist Fear once per day)

Goals for upcoming versions
	Add journal entries
	If you take too long, the chicken gets his Wish! Oh no! 